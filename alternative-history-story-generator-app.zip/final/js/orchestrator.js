/**
 * Orchestrator/Router for Alternative History Story Generator
 * Handles request routing, specialist coordination, and response assembly
 */

/* global SpecialistRegistry, DataUtils, ErrorUtils, TextUtils, TimeUtils */

class Orchestrator {
  constructor() {
    this.specialistRegistry = new SpecialistRegistry();
    this.predictionModels = new PredictionModelArray();
    this.researchAgent = new ResearchAgent();
    this.imageGenerator = new ImageGenerator();
    this.briefingAgent = new BriefingAgent();
    this.ttsService = new TTSService();
    this.auditLayer = new AuditLayer();
  }

  /**
   * Main entry point for story generation
   */
  async generateStory(request) {
    try {
      // Validate request
      const validation = DataUtils.validateRequest(request);
      if (!validation.isValid) {
        throw new Error(`Invalid request: ${validation.errors.join(', ')}`);
      }

      // Step 1: Route and plan
      const plan = await this.routeRequest(request);
      
      // Step 2: Execute specialist analysis
      const findings = await this.executeAnalysis(plan);
      
      // Step 3: Generate image
      const imageResult = await this.generateImage(findings, request.style);
      
      // Step 4: Create briefing
      const briefing = await this.createBriefing(findings, imageResult, request);
      
      // Step 5: Generate audio (if requested)
      const audioResult = await this.generateAudio(briefing, request);
      
      // Step 6: Audit and finalize
      const finalResult = await this.auditAndFinalize({
        briefing,
        image: imageResult,
        audio: audioResult,
        findings,
        plan
      });

      return finalResult;

    } catch (error) {
      ErrorUtils.logError(error, 'Orchestrator.generateStory');
      throw error;
    }
  }

  /**
   * Route request and create execution plan
   */
  async routeRequest(request) {
    const { hypothetical, lens, needs_realtime } = request;
    
    // Extract entities and classify intent
    const entities = TextUtils.extractEntities(hypothetical);
    const timeframe = TimeUtils.parseTimeframe(hypothetical);
    const selectedLens = lens === 'auto' ? 
      this.specialistRegistry.autoSelectSpecialist(hypothetical) : lens;

    // Determine if real-time data is needed
    const needsRealtime = needs_realtime || this.detectRealtimeNeed(hypothetical);
    
    // Create execution plan
    const plan = {
      request_id: this.generateRequestId(),
      hypothetical,
      lens: selectedLens,
      specialists: [selectedLens],
      entities,
      timeframe,
      needs_realtime: needsRealtime,
      data_calls: needsRealtime ? this.planDataCalls(selectedLens, entities) : [],
      image_seed: this.generateImageSeed(hypothetical, entities),
      created_at: TimeUtils.now()
    };

    // Check for mixed lens scenarios
    if (this.shouldUseMixedAnalysis(hypothetical)) {
      plan.specialists = this.selectMultipleSpecialists(hypothetical);
    }

    return plan;
  }

  /**
   * Execute specialist analysis based on plan
   */
  async executeAnalysis(plan) {
    const findings = [];
    
    for (const specialistLens of plan.specialists) {
      try {
        // Get specialist
        const specialist = this.specialistRegistry.getSpecialist(specialistLens);
        if (!specialist) {
          throw new Error(`Specialist not found: ${specialistLens}`);
        }

        // Gather real-time data if needed
        let dataBundle = {};
        if (plan.needs_realtime && plan.data_calls.length > 0) {
          dataBundle = await this.researchAgent.gatherData(plan.data_calls);
        }

        // Parse hypothetical for specialist
        const parsedHypothetical = specialist.parseHypothetical(plan.hypothetical);
        
        // Run specialist analysis
        const specialistFindings = await specialist.analyze(parsedHypothetical, dataBundle);
        
        // Add metadata
        specialistFindings.specialist = specialistLens;
        specialistFindings.execution_time = TimeUtils.now();
        
        findings.push(specialistFindings);

      } catch (error) {
        ErrorUtils.logError(error, `Specialist analysis: ${specialistLens}`);
        
        // Create fallback findings
        findings.push({
          specialist: specialistLens,
          error: error.message,
          normalized: { original: plan.hypothetical },
          assumptions: ["Analysis failed - using fallback"],
          analyses: [],
          uncertainties: ["Specialist analysis unavailable"],
          citations: [],
          disclaimer: "Analysis could not be completed due to technical issues."
        });
      }
    }

    // Fuse findings if multiple specialists
    return findings.length > 1 ? this.fuseFindings(findings) : findings[0];
  }

  /**
   * Generate image for the scenario
   */
  async generateImage(findings, style) {
    try {
      const imagePrompt = findings.image_prompt || 
        this.generateFallbackImagePrompt(findings, style.image_style);
      
      const imageResult = await this.imageGenerator.generate({
        prompt: imagePrompt,
        style: style.image_style || 'photo',
        seed: findings.image_seed
      });

      return imageResult;

    } catch (error) {
      ErrorUtils.logError(error, 'Image generation');
      
      return {
        url: null,
        alt: "Image generation unavailable",
        caption: "Visual representation could not be generated",
        error: error.message
      };
    }
  }

  /**
   * Create polished briefing
   */
  async createBriefing(findings, imageResult, request) {
    try {
      const briefingRequest = {
        findings,
        image_caption: imageResult.caption || imageResult.alt,
        style: {
          voice: request.style?.voice || 'neutral',
          reading_time: request.style?.reading_time || 'standard',
          lens: findings.specialist || request.lens
        }
      };

      const briefing = await this.briefingAgent.createBriefing(briefingRequest);
      return briefing;

    } catch (error) {
      ErrorUtils.logError(error, 'Briefing creation');
      
      // Fallback briefing
      return this.createFallbackBriefing(findings, imageResult);
    }
  }

  /**
   * Generate audio narration
   */
  async generateAudio(briefing, request) {
    try {
      if (!request.generate_audio) {
        return { url: null, duration_sec: 0 };
      }

      const audioResult = await this.ttsService.synthesize({
        text: briefing.full_text || this.extractTextFromBriefing(briefing),
        voice: request.style?.voice || 'neutral',
        format: 'mp3'
      });

      return audioResult;

    } catch (error) {
      ErrorUtils.logError(error, 'Audio generation');
      
      return {
        url: null,
        duration_sec: 0,
        error: error.message
      };
    }
  }

  /**
   * Audit and finalize response
   */
  async auditAndFinalize(components) {
    try {
      // Run audit checks
      const auditResult = await this.auditLayer.audit(components);
      
      // Apply safety measures
      const sanitizedBriefing = this.auditLayer.sanitizeBriefing(components.briefing);
      
      // Assemble final response
      const response = {
        title: sanitizedBriefing.title,
        executive_summary: sanitizedBriefing.executive_summary,
        sections: sanitizedBriefing.sections,
        image: components.image,
        audio: components.audio,
        citations: components.findings.citations || [],
        metadata: {
          specialist_used: components.findings.specialist,
          generation_time: TimeUtils.now(),
          request_id: components.plan.request_id,
          audit_flags: auditResult.flags,
          confidence_score: this.calculateConfidenceScore(components.findings)
        },
        explanation: {
          plan: components.plan,
          specialist_reasoning: components.findings.assumptions || [],
          data_sources: components.findings.citations || [],
          uncertainties: components.findings.uncertainties || []
        }
      };

      // Add disclaimers
      if (components.findings.disclaimer) {
        response.disclaimer = components.findings.disclaimer;
      }

      return response;

    } catch (error) {
      ErrorUtils.logError(error, 'Response finalization');
      throw error;
    }
  }

  // Helper methods

  generateRequestId() {
    return 'req_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  detectRealtimeNeed(hypothetical) {
    const realtimeKeywords = [
      'today', 'now', 'current', 'latest', 'recent', 'this week', 
      'this month', 'right now', 'currently', 'at present'
    ];
    
    const text = hypothetical.toLowerCase();
    return realtimeKeywords.some(keyword => text.includes(keyword));
  }

  planDataCalls(lens, entities) {
    const dataCalls = [];
    
    switch (lens) {
      case 'sports':
        dataCalls.push({ type: 'sports_data', entities: entities.organizations });
        break;
      case 'finance':
        dataCalls.push({ type: 'market_data', entities: entities.organizations });
        break;
      case 'weather':
        dataCalls.push({ type: 'weather_data', entities: entities.locations });
        break;
      case 'economics':
        dataCalls.push({ type: 'economic_data', entities: entities.locations });
        break;
    }
    
    return dataCalls;
  }

  generateImageSeed(hypothetical, entities) {
    // Create a seed based on content for consistent image generation
    const content = hypothetical + JSON.stringify(entities);
    let hash = 0;
    for (let i = 0; i < content.length; i++) {
      const char = content.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash);
  }

  shouldUseMixedAnalysis(hypothetical) {
    const text = hypothetical.toLowerCase();
    const lensKeywords = {
      history: ['war', 'battle', 'historical', 'past'],
      sports: ['team', 'game', 'player', 'match'],
      finance: ['stock', 'market', 'price', 'investment'],
      business: ['company', 'business', 'strategy', 'market'],
      economics: ['economy', 'gdp', 'inflation', 'policy'],
      weather: ['weather', 'storm', 'climate', 'temperature']
    };

    let matchCount = 0;
    for (const keywords of Object.values(lensKeywords)) {
      if (keywords.some(keyword => text.includes(keyword))) {
        matchCount++;
      }
    }

    return matchCount > 1;
  }

  selectMultipleSpecialists(hypothetical) {
    const text = hypothetical.toLowerCase();
    const specialists = [];
    
    // Use auto-selection for primary
    const primary = this.specialistRegistry.autoSelectSpecialist(hypothetical);
    specialists.push(primary);
    
    // Add secondary based on content
    if (text.includes('economic') || text.includes('market')) {
      if (!specialists.includes('economics')) specialists.push('economics');
    }
    if (text.includes('business') || text.includes('company')) {
      if (!specialists.includes('business')) specialists.push('business');
    }
    
    return specialists.slice(0, 2); // Limit to 2 specialists
  }

  fuseFindings(findingsArray) {
    const primary = findingsArray[0];
    const secondary = findingsArray.slice(1);

    // Combine analyses
    const combinedAnalyses = [...primary.analyses];
    secondary.forEach(findings => {
      combinedAnalyses.push(...findings.analyses);
    });

    // Combine uncertainties
    const combinedUncertainties = [...(primary.uncertainties || [])];
    secondary.forEach(findings => {
      if (findings.uncertainties) {
        combinedUncertainties.push(...findings.uncertainties);
      }
    });

    // Combine citations
    const combinedCitations = [...(primary.citations || [])];
    secondary.forEach(findings => {
      if (findings.citations) {
        combinedCitations.push(...findings.citations);
      }
    });

    return {
      ...primary,
      analyses: combinedAnalyses,
      uncertainties: [...new Set(combinedUncertainties)], // Remove duplicates
      citations: combinedCitations,
      specialist: findingsArray.map(f => f.specialist).join(' + '),
      mixed_analysis: true
    };
  }

  generateFallbackImagePrompt(findings, style) {
    const scenario = findings.normalized?.original || "alternative history scenario";
    return `${scenario}, ${style || 'photo'} style, professional composition, no text overlay`;
  }

  createFallbackBriefing(findings, imageResult) {
    const title = findings.specialist ? 
      `Alternative History Analysis: ${TextUtils.titleCase(findings.specialist)} Perspective` : 
      "Alternative History Analysis";
    
    const sections = [
      {
        heading: "Background",
        body: "This analysis examines the provided hypothetical scenario."
      },
      {
        heading: "Method", 
        body: "Standard analytical frameworks were applied to evaluate the scenario."
      },
      {
        heading: "Results",
        body: "The analysis provides insights into potential outcomes and implications."
      },
      {
        heading: "Uncertainties",
        body: "Several factors remain uncertain and could impact the final outcomes."
      }
    ];

    if (imageResult && imageResult.caption) {
      sections.push({
        heading: "What the Picture Shows",
        body: imageResult.caption
      });
    }

    return {
      title,
      executive_summary: "Analysis of the provided hypothetical scenario.",
      sections,
      full_text: "This is a fallback briefing due to technical issues with the primary analysis system."
    };
  }

  extractTextFromBriefing(briefing) {
    let text = briefing.title + ". " + briefing.executive_summary + ". ";
    
    briefing.sections.forEach(section => {
      text += section.heading + ". " + section.body + ". ";
    });
    
    return text;
  }

  calculateConfidenceScore(findings) {
    // Simple confidence calculation based on available data
    let score = 0.5; // Base score
    
    if (findings.analyses && findings.analyses.length > 0) score += 0.2;
    if (findings.citations && findings.citations.length > 0) score += 0.1;
    if (findings.key_numbers) score += 0.1;
    if (!findings.error) score += 0.1;
    
    return Math.min(score, 1.0);
  }
}

// Supporting service classes (simulated for MVP)

class PredictionModelArray {
  constructor() {
    this.models = {
      timeseries: new TimeSeriesModel(),
      montecarlo: new MonteCarloModel(),
      bayesian: new BayesianModel()
    };
  }

  async predict(type, data) {
    const model = this.models[type];
    if (!model) {
      throw new Error(`Prediction model not found: ${type}`);
    }
    
    return await model.predict(data);
  }
}

class TimeSeriesModel {
  async predict(data) {
    await DataUtils.simulateDelay(500);
    const dataPoints = data && data.length ? data.length : 12;
    return {
      forecast: Array.from({length: dataPoints}, () => Math.random() * 100),
      confidence_intervals: Array.from({length: dataPoints}, () => [Math.random() * 20, Math.random() * 20])
    };
  }
}

class MonteCarloModel {
  async predict(data) {
    await DataUtils.simulateDelay(800);
    const simulations = data && data.simulations ? data.simulations : 1000;
    const results = Array.from({length: simulations}, () => Math.random());
    
    return {
      mean: results.reduce((a, b) => a + b) / results.length,
      percentiles: {
        p5: this.percentile(results, 5),
        p25: this.percentile(results, 25),
        p50: this.percentile(results, 50),
        p75: this.percentile(results, 75),
        p95: this.percentile(results, 95)
      }
    };
  }

  percentile(arr, p) {
    const sorted = arr.sort((a, b) => a - b);
    const index = (p / 100) * (sorted.length - 1);
    return sorted[Math.floor(index)];
  }
}

class BayesianModel {
  async predict(data) {
    await DataUtils.simulateDelay(600);
    const priorStrength = data && data.prior ? data.prior : 0.5;
    return {
      posterior_mean: Math.random() * priorStrength + (1 - priorStrength) * 0.5,
      credible_interval: [Math.random() * 0.3, 0.7 + Math.random() * 0.3],
      bayes_factor: 1 + Math.random() * 10
    };
  }
}

class ResearchAgent {
  async gatherData(dataCalls) {
    await DataUtils.simulateDelay(1000);
    
    const dataBundle = {};
    
    for (const call of dataCalls) {
      dataBundle[call.type] = await this.fetchData(call);
    }
    
    return dataBundle;
  }

  async fetchData(call) {
    // Simulate API calls for different data types
    switch (call.type) {
      case 'sports_data':
        return this.generateSportsData(call.entities);
      case 'market_data':
        return this.generateMarketData(call.entities);
      case 'weather_data':
        return this.generateWeatherData(call.entities);
      case 'economic_data':
        return this.generateEconomicData(call.entities);
      default:
        return {};
    }
  }

  generateSportsData(entities) {
    return {
      teams: entities.map(entity => ({
        name: entity,
        record: `${Math.floor(Math.random() * 20)}-${Math.floor(Math.random() * 20)}`,
        rating: Math.random() * 100
      })),
      retrieved_at: TimeUtils.now()
    };
  }

  generateMarketData(entities) {
    return {
      stocks: entities.map(entity => ({
        symbol: entity.toUpperCase().slice(0, 4),
        price: 100 + Math.random() * 200,
        change: (Math.random() - 0.5) * 10
      })),
      retrieved_at: TimeUtils.now()
    };
  }

  generateWeatherData(entities) {
    return {
      locations: entities.map(entity => ({
        location: entity,
        temperature: Math.random() * 40 - 10,
        conditions: ['sunny', 'cloudy', 'rainy', 'stormy'][Math.floor(Math.random() * 4)]
      })),
      retrieved_at: TimeUtils.now()
    };
  }

  generateEconomicData(entities) {
    const regionCount = entities.length || 1;
    return {
      indicators: {
        gdp_growth: (Math.random() - 0.5) * 0.1 * regionCount,
        inflation: Math.random() * 0.05,
        unemployment: Math.random() * 0.1
      },
      regions: entities,
      retrieved_at: TimeUtils.now()
    };
  }
}

class ImageGenerator {
  async generate(request) {
    await DataUtils.simulateDelay(2000);
    
    // Simulate image generation
    return {
      url: null, // Would be actual image URL in production
      alt: request.prompt,
      caption: `Generated image: ${TextUtils.truncate(request.prompt, 100)}`,
      style: request.style,
      seed: request.seed,
      generated_at: TimeUtils.now()
    };
  }
}

class BriefingAgent {
  async createBriefing(request) {
    await DataUtils.simulateDelay(1000);
    
    const { findings, image_caption, style } = request;
    
    // Generate briefing based on findings
    const briefing = {
      title: this.generateTitle(findings, style.lens),
      executive_summary: this.generateExecutiveSummary(findings),
      sections: this.generateSections(findings, image_caption),
      full_text: ""
    };
    
    // Combine all text for TTS
    briefing.full_text = this.combineText(briefing);
    
    return briefing;
  }

  generateTitle(findings, lens) {
    const lensNames = {
      history: 'Historical Analysis',
      sports: 'Sports Analysis', 
      finance: 'Financial Impact Assessment',
      economics: 'Economic Impact Analysis',
      weather: 'Weather Impact Analysis',
      business: 'Business Strategy Analysis'
    };
    
    return `Alternative History ${lensNames[lens] || 'Analysis'}`;
  }

  generateExecutiveSummary(findings) {
    if (findings.analyses && findings.analyses.length > 0) {
      return findings.analyses[0].summary || "Comprehensive analysis of the hypothetical scenario reveals several key insights and potential outcomes.";
    }
    
    return "Analysis of the provided hypothetical scenario using specialized analytical frameworks.";
  }

  generateSections(findings, imageCaption) {
    const sections = [
      {
        heading: "Background",
        body: this.generateBackground(findings)
      },
      {
        heading: "Method",
        body: this.generateMethod(findings)
      },
      {
        heading: "Results", 
        body: this.generateResults(findings)
      }
    ];

    if (imageCaption) {
      sections.push({
        heading: "What the Picture Shows",
        body: imageCaption
      });
    }

    if (findings.uncertainties && findings.uncertainties.length > 0) {
      sections.push({
        heading: "Uncertainties",
        body: findings.uncertainties.join('. ') + '.'
      });
    }

    return sections;
  }

  generateBackground(findings) {
    return "This analysis examines the provided hypothetical scenario using established analytical frameworks and historical precedents to evaluate potential outcomes and implications.";
  }

  generateMethod(findings) {
    const specialist = findings.specialist || 'specialist';
    return `Our ${specialist} analyst employed domain-specific methodologies and analytical tools to assess the scenario's plausibility and potential consequences.`;
  }

  generateResults(findings) {
    if (findings.analyses && findings.analyses.length > 0) {
      const analysis = findings.analyses[0];
      let results = analysis.summary || "The analysis reveals several key findings.";
      
      if (analysis.key_numbers) {
        results += " Key metrics include: ";
        const numbers = Object.entries(analysis.key_numbers)
          .map(([key, value]) => `${key.replace(/_/g, ' ')}: ${typeof value === 'number' ? value.toFixed(2) : value}`)
          .join(', ');
        results += numbers + ".";
      }
      
      return results;
    }
    
    return "The analysis provides insights into the potential outcomes and implications of the hypothetical scenario.";
  }

  combineText(briefing) {
    let text = briefing.title + ". " + briefing.executive_summary + ". ";
    
    briefing.sections.forEach(section => {
      text += section.heading + ". " + section.body + ". ";
    });
    
    return text;
  }
}

class TTSService {
  async synthesize(request) {
    await DataUtils.simulateDelay(1500);
    
    // Simulate TTS generation
    const wordCount = request.text.split(' ').length;
    const estimatedDuration = Math.ceil(wordCount / 3); // ~3 words per second
    
    return {
      url: null, // Would be actual audio URL in production
      duration_sec: estimatedDuration,
      format: request.format || 'mp3',
      generated_at: TimeUtils.now()
    };
  }
}

class AuditLayer {
  async audit(components) {
    await DataUtils.simulateDelay(200);
    
    const flags = [];
    
    // Check for sensitive content
    if (this.containsSensitiveContent(components.briefing)) {
      flags.push('sensitive_content');
    }
    
    // Check for speculative claims
    if (this.containsSpeculativeClaims(components.briefing)) {
      flags.push('speculative_claims');
    }
    
    return { flags };
  }

  containsSensitiveContent(briefing) {
    const sensitiveKeywords = ['violence', 'discrimination', 'illegal'];
    const text = JSON.stringify(briefing).toLowerCase();
    
    return sensitiveKeywords.some(keyword => text.includes(keyword));
  }

  containsSpeculativeClaims(briefing) {
    const speculativeKeywords = ['will definitely', 'certainly will', 'guaranteed'];
    const text = JSON.stringify(briefing).toLowerCase();
    
    return speculativeKeywords.some(keyword => text.includes(keyword));
  }

  sanitizeBriefing(briefing) {
    // Add disclaimers and sanitize content
    const sanitized = { ...briefing };
    
    // Ensure disclaimer is present
    if (!sanitized.disclaimer) {
      sanitized.disclaimer = "This analysis is speculative and for educational purposes only.";
    }
    
    return sanitized;
  }
}

// Export for use in other modules
window.Orchestrator = Orchestrator;