/**
 * Main Application Controller for Alternative History Story Generator
 * Handles UI interactions, state management, and orchestrates the generation process
 */

/* global Orchestrator, Utils, ErrorUtils, DataUtils, TextUtils, TimeUtils, AnimationUtils, StorageUtils */

class AlternativeHistoryApp {
  constructor() {
    this.orchestrator = new Orchestrator();
    this.currentRequest = null;
    this.currentResponse = null;
    this.isGenerating = false;
    
    // UI Elements
    this.elements = {};
    
    // Audio player state
    this.audioPlayer = null;
    this.isPlaying = false;
    
    // Initialize app
    this.init();
  }

  /**
   * Initialize the application
   */
  init() {
    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.setupUI());
    } else {
      this.setupUI();
    }
  }

  /**
   * Setup UI elements and event listeners
   */
  setupUI() {
    try {
      // Cache DOM elements
      this.cacheElements();
      
      // Setup event listeners
      this.setupEventListeners();
      
      // Initialize UI state
      this.initializeUIState();
      
      // Load any saved state
      this.loadSavedState();
      
      console.log('Alternative History App initialized successfully');
      
    } catch (error) {
      ErrorUtils.logError(error, 'App initialization');
      ErrorUtils.showError('Failed to initialize application. Please refresh the page.');
    }
  }

  /**
   * Cache frequently used DOM elements
   */
  cacheElements() {
    const elementIds = [
      'hypothetical', 'generate-btn', 'needs-realtime', 'reading-time', 'image-style',
      'loading-state', 'loading-status', 'progress-bar', 'results-section',
      'briefing-title', 'specialist-used', 'generation-time', 'briefing-content',
      'image-card', 'generated-image', 'image-loading', 'image-caption',
      'explanation-panel', 'explanation-content', 'audio-player', 'audio-toggle',
      'explain-toggle', 'play-pause-btn', 'audio-progress', 'current-time', 'total-time'
    ];

    elementIds.forEach(id => {
      this.elements[id] = Utils.getElementById(id);
    });

    // Cache lens chips
    this.elements.lensChips = Utils.querySelectorAll('.lens-chip');
  }

  /**
   * Setup event listeners
   */
  setupEventListeners() {
    // Generate button
    if (this.elements['generate-btn']) {
      Utils.addEventListener(this.elements['generate-btn'], 'click', () => this.handleGenerate());
    }

    // Lens selection chips
    this.elements.lensChips.forEach(chip => {
      Utils.addEventListener(chip, 'click', (e) => this.handleLensSelection(e));
    });

    // Toggle buttons
    if (this.elements['audio-toggle']) {
      Utils.addEventListener(this.elements['audio-toggle'], 'click', () => this.toggleAudioPlayer());
    }

    if (this.elements['explain-toggle']) {
      Utils.addEventListener(this.elements['explain-toggle'], 'click', () => this.toggleExplanation());
    }

    // Audio controls
    if (this.elements['play-pause-btn']) {
      Utils.addEventListener(this.elements['play-pause-btn'], 'click', () => this.toggleAudioPlayback());
    }

    // Form validation
    if (this.elements.hypothetical) {
      Utils.addEventListener(this.elements.hypothetical, 'input', () => this.validateForm());
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));

    // Auto-save form data
    this.setupAutoSave();
  }

  /**
   * Initialize UI state
   */
  initializeUIState() {
    // Set default lens selection
    this.setActiveLens('auto');
    
    // Validate form initially
    this.validateForm();
    
    // Hide results initially
    if (this.elements['results-section']) {
      Utils.hide(this.elements['results-section']);
    }
    
    if (this.elements['loading-state']) {
      Utils.hide(this.elements['loading-state']);
    }
  }

  /**
   * Handle lens selection
   */
  handleLensSelection(event) {
    const chip = event.currentTarget;
    const lens = chip.dataset.lens;
    
    if (lens) {
      this.setActiveLens(lens);
    }
  }

  /**
   * Set active lens
   */
  setActiveLens(lens) {
    // Remove active class from all chips
    this.elements.lensChips.forEach(chip => {
      chip.classList.remove('active');
    });

    // Add active class to selected chip
    const activeChip = document.querySelector(`[data-lens="${lens}"]`);
    if (activeChip) {
      activeChip.classList.add('active');
    }

    // Store selection
    this.selectedLens = lens;
  }

  /**
   * Validate form inputs
   */
  validateForm() {
    const hypothetical = this.elements.hypothetical?.value?.trim() || '';
    const isValid = hypothetical.length >= 10;
    
    if (this.elements['generate-btn']) {
      this.elements['generate-btn'].disabled = !isValid || this.isGenerating;
    }

    return isValid;
  }

  /**
   * Handle generate button click
   */
  async handleGenerate() {
    try {
      if (!this.validateForm() || this.isGenerating) {
        return;
      }

      // Prepare request
      const request = this.buildRequest();
      
      // Validate request
      const validation = DataUtils.validateRequest(request);
      if (!validation.isValid) {
        ErrorUtils.showError(validation.errors.join(', '));
        return;
      }

      // Start generation process
      await this.generateStory(request);

    } catch (error) {
      ErrorUtils.logError(error, 'Generate story');
      ErrorUtils.showError('Failed to generate story. Please try again.');
      this.resetGenerationState();
    }
  }

  /**
   * Build request object from form data
   */
  buildRequest() {
    return {
      hypothetical: this.elements.hypothetical?.value?.trim() || '',
      lens: this.selectedLens || 'auto',
      needs_realtime: this.elements['needs-realtime']?.checked || false,
      generate_audio: true, // Always generate for demo
      style: {
        reading_time: this.elements['reading-time']?.value || 'standard',
        voice: 'neutral',
        image_style: this.elements['image-style']?.value || 'photo'
      }
    };
  }

  /**
   * Generate story using orchestrator
   */
  async generateStory(request) {
    this.isGenerating = true;
    this.currentRequest = request;
    
    try {
      // Show loading state
      this.showLoadingState();
      
      // Update progress through generation steps
      await this.updateProgress('Routing to specialist...', 10);
      
      // Generate story
      const response = await this.orchestrator.generateStory(request);
      
      await this.updateProgress('Finalizing results...', 90);
      
      // Store response
      this.currentResponse = response;
      
      // Display results
      await this.displayResults(response);
      
      // Save to storage
      this.saveToHistory(request, response);
      
      await this.updateProgress('Complete!', 100);
      
      // Hide loading and show results
      setTimeout(() => {
        this.hideLoadingState();
        this.showResults();
      }, 500);

    } catch (error) {
      ErrorUtils.logError(error, 'Story generation');
      ErrorUtils.showError('Failed to generate story: ' + error.message);
      this.hideLoadingState();
    } finally {
      this.isGenerating = false;
      this.validateForm(); // Re-enable button
    }
  }

  /**
   * Show loading state with progress
   */
  showLoadingState() {
    if (this.elements['results-section']) {
      Utils.hide(this.elements['results-section']);
    }
    
    if (this.elements['loading-state']) {
      Utils.show(this.elements['loading-state'], 'fade-in');
    }
    
    // Reset progress
    this.updateProgressBar(0);
  }

  /**
   * Hide loading state
   */
  hideLoadingState() {
    if (this.elements['loading-state']) {
      Utils.hide(this.elements['loading-state']);
    }
  }

  /**
   * Update loading progress
   */
  async updateProgress(status, percent) {
    if (this.elements['loading-status']) {
      this.elements['loading-status'].textContent = status;
    }
    
    this.updateProgressBar(percent);
    
    // Simulate processing time
    await DataUtils.simulateDelay(300);
  }

  /**
   * Update progress bar
   */
  updateProgressBar(percent) {
    if (this.elements['progress-bar']) {
      AnimationUtils.animateProgress(this.elements['progress-bar'], percent, 500);
    }
  }

  /**
   * Display generation results
   */
  async displayResults(response) {
    try {
      // Update briefing
      this.displayBriefing(response);
      
      // Update image
      this.displayImage(response.image);
      
      // Setup audio
      this.setupAudio(response.audio);
      
      // Update explanation
      this.displayExplanation(response.explanation);
      
      // Update metadata
      this.displayMetadata(response.metadata);

    } catch (error) {
      ErrorUtils.logError(error, 'Display results');
      throw error;
    }
  }

  /**
   * Display briefing content
   */
  displayBriefing(response) {
    // Update title
    if (this.elements['briefing-title']) {
      this.elements['briefing-title'].textContent = response.title;
    }

    // Update metadata
    if (this.elements['specialist-used']) {
      this.elements['specialist-used'].textContent = 
        TextUtils.titleCase(response.metadata.specialist_used) + ' Analysis';
    }

    if (this.elements['generation-time']) {
      this.elements['generation-time'].textContent = 
        'Generated ' + TimeUtils.formatTimestamp(response.metadata.generation_time);
    }

    // Update content
    if (this.elements['briefing-content']) {
      this.elements['briefing-content'].innerHTML = this.formatBriefingContent(response);
    }
  }

  /**
   * Format briefing content as HTML
   */
  formatBriefingContent(response) {
    let html = '';
    
    // Executive summary
    if (response.executive_summary) {
      html += `<div class="briefing-section">
        <h3>Executive Summary</h3>
        <p>${TextUtils.sanitizeHtml(response.executive_summary)}</p>
      </div>`;
    }

    // Sections
    if (response.sections) {
      response.sections.forEach(section => {
        html += `<div class="briefing-section">
          <h3>${TextUtils.sanitizeHtml(section.heading)}</h3>
          <p>${TextUtils.sanitizeHtml(section.body)}</p>
        </div>`;
      });
    }

    // Key numbers if available
    if (response.metadata && response.metadata.key_numbers) {
      html += this.formatKeyNumbers(response.metadata.key_numbers);
    }

    // Citations
    if (response.citations && response.citations.length > 0) {
      html += this.formatCitations(response.citations);
    }

    // Disclaimer
    if (response.disclaimer) {
      html += `<div class="briefing-section">
        <h3>Disclaimer</h3>
        <p><em>${TextUtils.sanitizeHtml(response.disclaimer)}</em></p>
      </div>`;
    }

    return html;
  }

  /**
   * Format key numbers display
   */
  formatKeyNumbers(keyNumbers) {
    let html = '<div class="briefing-section"><h3>Key Numbers</h3><div class="key-numbers">';
    
    Object.entries(keyNumbers).forEach(([key, value]) => {
      const label = TextUtils.titleCase(key.replace(/_/g, ' '));
      const formattedValue = typeof value === 'number' ? 
        (value < 1 ? (value * 100).toFixed(1) + '%' : value.toFixed(2)) : 
        value;
      
      html += `<div class="key-number">
        <span class="key-number-value">${formattedValue}</span>
        <span class="key-number-label">${label}</span>
      </div>`;
    });
    
    html += '</div></div>';
    return html;
  }

  /**
   * Format citations list
   */
  formatCitations(citations) {
    let html = '<div class="briefing-section"><h3>Sources</h3><ul class="citations-list">';
    
    citations.forEach((citation, index) => {
      html += `<li class="citation-item">
        <span class="citation-number">${index + 1}</span>
        <div class="citation-content">
          <div class="citation-title">${TextUtils.sanitizeHtml(citation.title)}</div>
          ${citation.url && citation.url !== '#' ? 
            `<a href="${citation.url}" class="citation-url" target="_blank" rel="noopener">${citation.url}</a>` : 
            ''}
        </div>
      </li>`;
    });
    
    html += '</ul></div>';
    return html;
  }

  /**
   * Display image
   */
  displayImage(imageData) {
    if (!this.elements['generated-image'] || !this.elements['image-caption']) {
      return;
    }

    if (imageData.url) {
      // Show actual image
      this.elements['generated-image'].src = imageData.url;
      this.elements['generated-image'].alt = imageData.alt || '';
      Utils.hide(this.elements['image-loading']);
    } else {
      // Show placeholder or hide image section
      Utils.hide(this.elements['image-card']);
    }

    // Update caption
    if (imageData.caption) {
      this.elements['image-caption'].textContent = imageData.caption;
    }
  }

  /**
   * Setup audio player
   */
  setupAudio(audioData) {
    if (!audioData.url) {
      // Hide audio player if no audio
      if (this.elements['audio-player']) {
        Utils.hide(this.elements['audio-player']);
      }
      return;
    }

    // Create audio element
    this.audioPlayer = new Audio(audioData.url);
    
    // Setup audio event listeners
    this.audioPlayer.addEventListener('loadedmetadata', () => {
      if (this.elements['total-time']) {
        this.elements['total-time'].textContent = 
          TimeUtils.formatDuration(this.audioPlayer.duration);
      }
    });

    this.audioPlayer.addEventListener('timeupdate', () => {
      this.updateAudioProgress();
    });

    this.audioPlayer.addEventListener('ended', () => {
      this.isPlaying = false;
      this.updatePlayButton();
    });
  }

  /**
   * Toggle audio player visibility
   */
  toggleAudioPlayer() {
    if (this.elements['audio-player']) {
      Utils.toggle(this.elements['audio-player'], 'slide-in-right');
    }
    
    // Update button state
    if (this.elements['audio-toggle']) {
      this.elements['audio-toggle'].classList.toggle('active');
    }
  }

  /**
   * Toggle audio playback
   */
  toggleAudioPlayback() {
    if (!this.audioPlayer) return;

    if (this.isPlaying) {
      this.audioPlayer.pause();
      this.isPlaying = false;
    } else {
      this.audioPlayer.play();
      this.isPlaying = true;
    }

    this.updatePlayButton();
  }

  /**
   * Update play button icon
   */
  updatePlayButton() {
    if (!this.elements['play-pause-btn']) return;

    const icon = this.isPlaying ? 
      `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
      </svg>` :
      `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h8m-9-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
      </svg>`;

    this.elements['play-pause-btn'].innerHTML = icon;
  }

  /**
   * Update audio progress
   */
  updateAudioProgress() {
    if (!this.audioPlayer || !this.elements['audio-progress']) return;

    const progress = (this.audioPlayer.currentTime / this.audioPlayer.duration) * 100;
    this.elements['audio-progress'].style.width = `${progress}%`;

    if (this.elements['current-time']) {
      this.elements['current-time'].textContent = 
        TimeUtils.formatDuration(this.audioPlayer.currentTime);
    }
  }

  /**
   * Display explanation panel
   */
  displayExplanation(explanation) {
    if (!this.elements['explanation-content'] || !explanation) {
      return;
    }

    let html = '';

    // Plan information
    if (explanation.plan) {
      html += `<div class="explanation-step">
        <div class="explanation-step-title">
          <span class="explanation-step-number">1</span>
          Routing & Planning
        </div>
        <div class="explanation-step-content">
          Selected ${TextUtils.titleCase(explanation.plan.lens)} specialist based on content analysis.
          ${explanation.plan.needs_realtime ? 'Real-time data collection was enabled.' : ''}
        </div>
      </div>`;
    }

    // Specialist reasoning
    if (explanation.specialist_reasoning && explanation.specialist_reasoning.length > 0) {
      html += `<div class="explanation-step">
        <div class="explanation-step-title">
          <span class="explanation-step-number">2</span>
          Analysis Assumptions
        </div>
        <div class="explanation-step-content">
          <ul>
            ${explanation.specialist_reasoning.map(assumption => 
              `<li>${TextUtils.sanitizeHtml(assumption)}</li>`
            ).join('')}
          </ul>
        </div>
      </div>`;
    }

    // Data sources
    if (explanation.data_sources && explanation.data_sources.length > 0) {
      html += `<div class="explanation-step">
        <div class="explanation-step-title">
          <span class="explanation-step-number">3</span>
          Data Sources
        </div>
        <div class="explanation-step-content">
          Analysis incorporated ${explanation.data_sources.length} data source(s) and references.
        </div>
      </div>`;
    }

    // Uncertainties
    if (explanation.uncertainties && explanation.uncertainties.length > 0) {
      html += `<div class="explanation-step">
        <div class="explanation-step-title">
          <span class="explanation-step-number">4</span>
          Key Uncertainties
        </div>
        <div class="explanation-step-content">
          <ul>
            ${explanation.uncertainties.slice(0, 3).map(uncertainty => 
              `<li>${TextUtils.sanitizeHtml(uncertainty)}</li>`
            ).join('')}
          </ul>
        </div>
      </div>`;
    }

    this.elements['explanation-content'].innerHTML = html;
  }

  /**
   * Toggle explanation panel
   */
  toggleExplanation() {
    if (this.elements['explanation-panel']) {
      Utils.toggle(this.elements['explanation-panel'], 'fade-in-up');
    }
    
    // Update button state
    if (this.elements['explain-toggle']) {
      this.elements['explain-toggle'].classList.toggle('active');
    }
  }

  /**
   * Display metadata
   */
  displayMetadata(metadata) {
    // Update confidence indicator if available
    if (metadata.confidence_score) {
      const confidence = Math.round(metadata.confidence_score * 100);
      // Could add confidence indicator to UI
    }
  }

  /**
   * Show results section
   */
  showResults() {
    if (this.elements['results-section']) {
      Utils.show(this.elements['results-section'], 'fade-in-up');
    }
  }

  /**
   * Reset generation state
   */
  resetGenerationState() {
    this.isGenerating = false;
    this.hideLoadingState();
    this.validateForm();
  }

  /**
   * Handle keyboard shortcuts
   */
  handleKeyboardShortcuts(event) {
    // Ctrl/Cmd + Enter to generate
    if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
      event.preventDefault();
      this.handleGenerate();
    }
    
    // Escape to close panels
    if (event.key === 'Escape') {
      if (this.elements['explanation-panel'] && !this.elements['explanation-panel'].classList.contains('hidden')) {
        this.toggleExplanation();
      }
      if (this.elements['audio-player'] && !this.elements['audio-player'].classList.contains('hidden')) {
        this.toggleAudioPlayer();
      }
    }
  }

  /**
   * Setup auto-save functionality
   */
  setupAutoSave() {
    let saveTimeout;
    
    const autoSave = () => {
      clearTimeout(saveTimeout);
      saveTimeout = setTimeout(() => {
        this.saveFormState();
      }, 1000);
    };

    if (this.elements.hypothetical) {
      Utils.addEventListener(this.elements.hypothetical, 'input', autoSave);
    }
  }

  /**
   * Save form state to localStorage
   */
  saveFormState() {
    const state = {
      hypothetical: this.elements.hypothetical?.value || '',
      lens: this.selectedLens,
      needs_realtime: this.elements['needs-realtime']?.checked || false,
      reading_time: this.elements['reading-time']?.value || 'standard',
      image_style: this.elements['image-style']?.value || 'photo'
    };

    StorageUtils.save('form_state', state);
  }

  /**
   * Load saved form state
   */
  loadSavedState() {
    const state = StorageUtils.load('form_state');
    
    if (state) {
      if (this.elements.hypothetical && state.hypothetical) {
        this.elements.hypothetical.value = state.hypothetical;
      }
      
      if (state.lens) {
        this.setActiveLens(state.lens);
      }
      
      if (this.elements['needs-realtime']) {
        this.elements['needs-realtime'].checked = state.needs_realtime || false;
      }
      
      if (this.elements['reading-time'] && state.reading_time) {
        this.elements['reading-time'].value = state.reading_time;
      }
      
      if (this.elements['image-style'] && state.image_style) {
        this.elements['image-style'].value = state.image_style;
      }
      
      this.validateForm();
    }
  }

  /**
   * Save generation to history
   */
  saveToHistory(request, response) {
    const historyItem = {
      id: response.metadata.request_id,
      timestamp: response.metadata.generation_time,
      request: {
        hypothetical: request.hypothetical,
        lens: request.lens
      },
      response: {
        title: response.title,
        specialist: response.metadata.specialist_used
      }
    };

    let history = StorageUtils.load('generation_history') || [];
    history.unshift(historyItem);
    
    // Keep only last 10 items
    history = history.slice(0, 10);
    
    StorageUtils.save('generation_history', history);
  }

  /**
   * Load generation history
   */
  loadHistory() {
    return StorageUtils.load('generation_history') || [];
  }
}

// Initialize app when script loads
let app;

// Wait for all dependencies to load
function initializeApp() {
  if (typeof Utils !== 'undefined' && 
      typeof SpecialistRegistry !== 'undefined' && 
      typeof Orchestrator !== 'undefined') {
    app = new AlternativeHistoryApp();
  } else {
    // Retry after a short delay
    setTimeout(initializeApp, 100);
  }
}

// Start initialization
initializeApp();