/**
 * Utility functions for Alternative History Story Generator
 */

// DOM utility functions
const Utils = {
  /**
   * Get element by ID with error handling
   */
  getElementById: (id) => {
    const element = document.getElementById(id);
    if (!element) {
      console.warn(`Element with ID '${id}' not found`);
    }
    return element;
  },

  /**
   * Query selector with error handling
   */
  querySelector: (selector) => {
    const element = document.querySelector(selector);
    if (!element) {
      console.warn(`Element with selector '${selector}' not found`);
    }
    return element;
  },

  /**
   * Query all selectors
   */
  querySelectorAll: (selector) => {
    return document.querySelectorAll(selector);
  },

  /**
   * Add event listener with error handling
   */
  addEventListener: (element, event, handler) => {
    if (element && typeof handler === 'function') {
      element.addEventListener(event, handler);
    } else {
      console.warn('Invalid element or handler for event listener');
    }
  },

  /**
   * Remove event listener
   */
  removeEventListener: (element, event, handler) => {
    if (element && typeof handler === 'function') {
      element.removeEventListener(event, handler);
    }
  },

  /**
   * Show element with animation
   */
  show: (element, animationClass = 'fade-in') => {
    if (element) {
      element.classList.remove('hidden');
      element.classList.add(animationClass);
    }
  },

  /**
   * Hide element
   */
  hide: (element) => {
    if (element) {
      element.classList.add('hidden');
    }
  },

  /**
   * Toggle element visibility
   */
  toggle: (element, animationClass = 'fade-in') => {
    if (element) {
      if (element.classList.contains('hidden')) {
        Utils.show(element, animationClass);
      } else {
        Utils.hide(element);
      }
    }
  }
};

// Text processing utilities
const TextUtils = {
  /**
   * Sanitize HTML content
   */
  sanitizeHtml: (html) => {
    const div = document.createElement('div');
    div.textContent = html;
    return div.innerHTML;
  },

  /**
   * Truncate text to specified length
   */
  truncate: (text, maxLength = 100) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength).trim() + '...';
  },

  /**
   * Capitalize first letter of each word
   */
  titleCase: (str) => {
    return str.replace(/\w\S*/g, (txt) => 
      txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
    );
  },

  /**
   * Extract entities from text (simple implementation)
   */
  extractEntities: (text) => {
    const entities = {
      dates: [],
      locations: [],
      organizations: [],
      people: []
    };

    // Simple regex patterns for entity extraction
    const datePattern = /\b\d{4}\b|\b\d{1,2}\/\d{1,2}\/\d{4}\b|\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}\b/gi;
    const locationPattern = /\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*(?:\s+(?:City|State|Country|Bay|Area|Valley|Mountains?))\b/g;
    
    entities.dates = text.match(datePattern) || [];
    entities.locations = text.match(locationPattern) || [];

    return entities;
  },

  /**
   * Generate reading time estimate
   */
  estimateReadingTime: (text, wordsPerMinute = 200) => {
    const words = text.trim().split(/\s+/).length;
    const minutes = Math.ceil(words / wordsPerMinute);
    return minutes;
  }
};

// Time and date utilities
const TimeUtils = {
  /**
   * Format timestamp to readable string
   */
  formatTimestamp: (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  },

  /**
   * Get current timestamp
   */
  now: () => Date.now(),

  /**
   * Format duration in seconds to MM:SS
   */
  formatDuration: (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  },

  /**
   * Parse timeframe from text
   */
  parseTimeframe: (text) => {
    const currentYear = new Date().getFullYear();
    const yearMatches = text.match(/\b(19|20)\d{2}\b/g);
    
    if (yearMatches && yearMatches.length > 0) {
      const years = yearMatches.map(y => parseInt(y)).sort();
      return {
        start: years[0],
        end: years[years.length - 1] || currentYear
      };
    }
    
    return {
      start: currentYear,
      end: currentYear
    };
  }
};

// API and data utilities
const DataUtils = {
  /**
   * Make HTTP request with error handling
   */
  async fetchData(url, options = {}) {
    try {
      const response = await fetch(url, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers
        },
        ...options
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Fetch error:', error);
      throw error;
    }
  },

  /**
   * Simulate API delay for demo purposes
   */
  async simulateDelay(ms = 1000) {
    return new Promise(resolve => setTimeout(resolve, ms));
  },

  /**
   * Generate mock data for development
   */
  generateMockResponse: (hypothetical, lens) => {
    return {
      title: `Alternative History Analysis: ${TextUtils.titleCase(lens)} Perspective`,
      executive_summary: `Analysis of the hypothetical scenario "${TextUtils.truncate(hypothetical, 100)}" from a ${lens} perspective.`,
      sections: [
        {
          heading: "Background",
          body: "This analysis examines the provided hypothetical scenario using established methodologies and historical precedents."
        },
        {
          heading: "Method",
          body: `Our ${lens} specialist employed domain-specific analytical frameworks to evaluate the scenario's plausibility and potential outcomes.`
        },
        {
          heading: "Results",
          body: "Based on our analysis, several key findings emerge that illuminate the potential consequences of this alternative timeline."
        },
        {
          heading: "Uncertainties",
          body: "As with all counterfactual analysis, certain variables remain uncertain and could significantly impact the outcomes."
        }
      ],
      image: {
        url: null,
        alt: "Generated visualization of the alternative history scenario"
      },
      audio: {
        url: null,
        duration_sec: 0
      },
      citations: [
        {
          title: "Historical Analysis Framework",
          url: "#"
        }
      ],
      metadata: {
        specialist_used: lens,
        generation_time: TimeUtils.now(),
        entities: TextUtils.extractEntities(hypothetical),
        timeframe: TimeUtils.parseTimeframe(hypothetical)
      }
    };
  },

  /**
   * Validate request data
   */
  validateRequest: (data) => {
    const errors = [];

    if (!data.hypothetical || data.hypothetical.trim().length < 10) {
      errors.push('Hypothetical scenario must be at least 10 characters long');
    }

    if (!data.lens || !['auto', 'history', 'sports', 'finance', 'economics', 'weather', 'business'].includes(data.lens)) {
      errors.push('Invalid analysis lens selected');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
};

// Storage utilities
const StorageUtils = {
  /**
   * Save data to localStorage
   */
  save: (key, data) => {
    try {
      localStorage.setItem(key, JSON.stringify(data));
      return true;
    } catch (error) {
      console.error('Storage save error:', error);
      return false;
    }
  },

  /**
   * Load data from localStorage
   */
  load: (key) => {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Storage load error:', error);
      return null;
    }
  },

  /**
   * Remove data from localStorage
   */
  remove: (key) => {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (error) {
      console.error('Storage remove error:', error);
      return false;
    }
  },

  /**
   * Clear all stored data
   */
  clear: () => {
    try {
      localStorage.clear();
      return true;
    } catch (error) {
      console.error('Storage clear error:', error);
      return false;
    }
  }
};

// Animation utilities
const AnimationUtils = {
  /**
   * Animate progress bar
   */
  animateProgress: (element, targetPercent, duration = 1000) => {
    if (!element) return;

    let start = 0;
    const startTime = performance.now();

    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      const currentPercent = start + (targetPercent - start) * progress;
      element.style.width = `${currentPercent}%`;

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  },

  /**
   * Typewriter effect for text
   */
  typewriter: (element, text, speed = 50) => {
    if (!element) return;

    element.textContent = '';
    let i = 0;

    const type = () => {
      if (i < text.length) {
        element.textContent += text.charAt(i);
        i++;
        setTimeout(type, speed);
      }
    };

    type();
  },

  /**
   * Fade in element
   */
  fadeIn: (element, duration = 300) => {
    if (!element) return;

    element.style.opacity = '0';
    element.style.display = 'block';

    let start = performance.now();

    const fade = (timestamp) => {
      const elapsed = timestamp - start;
      const progress = Math.min(elapsed / duration, 1);
      
      element.style.opacity = progress;

      if (progress < 1) {
        requestAnimationFrame(fade);
      }
    };

    requestAnimationFrame(fade);
  }
};

// Error handling utilities
const ErrorUtils = {
  /**
   * Display user-friendly error message
   */
  showError: (message, container = null) => {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4';
    errorDiv.innerHTML = `
      <div class="flex items-center">
        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
        </svg>
        <span>${message}</span>
      </div>
    `;

    if (container) {
      container.insertBefore(errorDiv, container.firstChild);
    } else {
      document.body.insertBefore(errorDiv, document.body.firstChild);
    }

    // Auto-remove after 5 seconds
    setTimeout(() => {
      if (errorDiv.parentNode) {
        errorDiv.parentNode.removeChild(errorDiv);
      }
    }, 5000);
  },

  /**
   * Log error with context
   */
  logError: (error, context = '') => {
    console.error(`[${new Date().toISOString()}] ${context}:`, error);
  }
};

// Declare globals for linting
/* global Utils, TextUtils, TimeUtils, DataUtils, StorageUtils, AnimationUtils, ErrorUtils */

// Export utilities for use in other modules
window.Utils = Utils;
window.TextUtils = TextUtils;
window.TimeUtils = TimeUtils;
window.DataUtils = DataUtils;
window.StorageUtils = StorageUtils;
window.AnimationUtils = AnimationUtils;
window.ErrorUtils = ErrorUtils;