/**
 * Specialist Chains for Alternative History Story Generator
 * Each specialist implements domain-specific analysis logic
 */

/* global TextUtils, TimeUtils, DataUtils */

// Base Specialist Class
class BaseSpecialist {
  constructor(name, domain) {
    this.name = name;
    this.domain = domain;
  }

  /**
   * Parse and normalize the hypothetical scenario
   */
  parseHypothetical(hypothetical) {
    const entities = TextUtils.extractEntities(hypothetical);
    const timeframe = TimeUtils.parseTimeframe(hypothetical);
    
    return {
      original: hypothetical,
      normalized: hypothetical.trim(),
      entities,
      timeframe,
      keywords: this.extractKeywords(hypothetical)
    };
  }

  /**
   * Extract domain-specific keywords
   */
  extractKeywords(text) {
    const words = text.toLowerCase().split(/\W+/);
    return words.filter(word => word.length > 3);
  }

  /**
   * Generate assumptions based on the scenario
   */
  generateAssumptions(parsedHypothetical) {
    const baseAssumptions = [
      "Analysis assumes historical accuracy of baseline events",
      "Economic and social conditions remain relatively stable unless specified",
      "Technological capabilities remain consistent with the time period"
    ];
    
    // Add scenario-specific assumptions based on timeframe
    if (parsedHypothetical.timeframe && parsedHypothetical.timeframe.start < 1900) {
      baseAssumptions.push("Pre-industrial social and economic structures apply");
    }
    
    return baseAssumptions;
  }

  /**
   * Base analysis method - to be overridden by specialists
   */
  async analyze(parsedHypothetical, dataBundle = {}) {
    throw new Error('analyze method must be implemented by specialist subclass');
  }

  /**
   * Generate image prompt for the scenario
   */
  generateImagePrompt(analysis, style = 'photo') {
    const scenario = analysis.scenario || analysis.normalized;
    const era = analysis.timeframe ? `${analysis.timeframe.start}s era` : 'historical period';
    
    const styleMap = {
      'photo': 'photojournalistic style, high detail, realistic',
      'illustration': 'detailed illustration, artistic rendering',
      'retro-newspaper': 'vintage newspaper style, sepia tones, classic typography',
      'oil': 'oil painting style, rich textures, classical composition',
      'isometric': 'isometric view, clean lines, modern design'
    };

    return {
      prompt: `${scenario}, ${era}, ${styleMap[style] || styleMap.photo}, professional composition, no text overlay`,
      negative_prompt: 'text, watermarks, low quality, distorted, blurry',
      caption: `Visual representation of the alternative history scenario: ${TextUtils.truncate(scenario, 100)}`
    };
  }
}

// History Specialist
class HistorySpecialist extends BaseSpecialist {
  constructor() {
    super('History Analyst', 'history');
    this.historicalPeriods = {
      'ancient': { start: -3000, end: 500 },
      'medieval': { start: 500, end: 1500 },
      'renaissance': { start: 1400, end: 1700 },
      'industrial': { start: 1750, end: 1900 },
      'modern': { start: 1900, end: 2000 },
      'contemporary': { start: 2000, end: new Date().getFullYear() }
    };
  }

  extractKeywords(text) {
    const historyKeywords = [
      'war', 'battle', 'empire', 'revolution', 'treaty', 'invasion', 'conquest',
      'dynasty', 'kingdom', 'republic', 'democracy', 'monarchy', 'civilization',
      'discovery', 'exploration', 'colonization', 'independence', 'unification'
    ];
    
    const words = text.toLowerCase().split(/\W+/);
    return words.filter(word => 
      word.length > 3 && (historyKeywords.includes(word) || /\d{4}/.test(word))
    );
  }

  identifyHistoricalPeriod(timeframe) {
    const year = timeframe.start || new Date().getFullYear();
    
    for (const [period, range] of Object.entries(this.historicalPeriods)) {
      if (year >= range.start && year <= range.end) {
        return period;
      }
    }
    return 'unknown';
  }

  async analyze(parsedHypothetical, dataBundle = {}) {
    const period = this.identifyHistoricalPeriod(parsedHypothetical.timeframe);
    
    // Simulate historical analysis
    await DataUtils.simulateDelay(1500);
    
    // Use dataBundle if available for enhanced analysis
    const hasRealtimeData = Object.keys(dataBundle).length > 0;

    const analysis = {
      name: "Historical Counterfactual Analysis",
      summary: `Counterfactual analysis of ${parsedHypothetical.normalized}`,
      period: period,
      plausibility_score: this.calculatePlausibility(parsedHypothetical),
      causal_factors: this.identifyCausalFactors(parsedHypothetical),
      key_numbers: {
        plausibility: this.calculatePlausibility(parsedHypothetical),
        historical_precedents: Math.floor(Math.random() * 10) + 1,
        confidence_level: hasRealtimeData ? 0.85 : 0.75
      },
      historical_precedents: this.findPrecedents(parsedHypothetical),
      alternative_outcomes: this.generateAlternativeOutcomes(parsedHypothetical),
      sources: [
        { title: "Historical Analysis Framework", url: "#", retrieved_at: TimeUtils.now() },
        { title: "Counterfactual Methodology", url: "#", retrieved_at: TimeUtils.now() }
      ]
    };

    return {
      normalized: parsedHypothetical,
      assumptions: this.generateAssumptions(parsedHypothetical),
      analyses: [analysis],
      uncertainties: [
        "Historical sources may be incomplete or biased",
        "Complex social and economic factors difficult to model",
        "Butterfly effect may amplify small changes unpredictably"
      ],
      image_prompt: this.generateImagePrompt(parsedHypothetical, 'retro-newspaper').prompt,
      citations: analysis.sources,
      disclaimer: "This analysis is speculative and based on historical patterns and precedents."
    };
  }

  calculatePlausibility(parsedHypothetical) {
    // Simple plausibility scoring based on historical factors
    let score = 0.5; // Base score
    
    // Adjust based on time period (more recent = more data = higher confidence)
    if (parsedHypothetical.timeframe.start > 1800) score += 0.2;
    if (parsedHypothetical.timeframe.start > 1900) score += 0.1;
    
    // Adjust based on complexity (more entities = more complex = lower plausibility)
    const entityCount = Object.values(parsedHypothetical.entities).flat().length;
    score -= Math.min(entityCount * 0.05, 0.3);
    
    return Math.max(0.1, Math.min(0.95, score));
  }

  identifyCausalFactors(parsedHypothetical) {
    return [
      "Political climate and power structures",
      "Economic conditions and trade relationships",
      "Technological capabilities of the era",
      "Social and cultural factors",
      "Geographic and environmental constraints"
    ];
  }

  findPrecedents(parsedHypothetical) {
    return [
      "Similar historical events with documented outcomes",
      "Comparable political or social transformations",
      "Analogous technological or military developments"
    ];
  }

  generateAlternativeOutcomes(parsedHypothetical) {
    return [
      "Most likely scenario based on historical patterns",
      "Optimistic outcome with favorable conditions",
      "Pessimistic outcome with adverse factors"
    ];
  }
}

// Sports Specialist
class SportsSpecialist extends BaseSpecialist {
  constructor() {
    super('Sports Analyst', 'sports');
    this.sportsKeywords = [
      'team', 'player', 'game', 'match', 'season', 'championship', 'tournament',
      'score', 'win', 'loss', 'playoff', 'draft', 'trade', 'injury', 'coach'
    ];
  }

  extractKeywords(text) {
    const words = text.toLowerCase().split(/\W+/);
    return words.filter(word => 
      word.length > 3 && this.sportsKeywords.includes(word)
    );
  }

  async analyze(parsedHypothetical, dataBundle = {}) {
    await DataUtils.simulateDelay(1200);

    // Use dataBundle for enhanced sports analysis if available
    const hasRealtimeData = Object.keys(dataBundle).length > 0;
    const matchupAnalysis = this.analyzeMatchup(parsedHypothetical, hasRealtimeData);
    
    const analysis = {
      name: "Sports Matchup Analysis",
      summary: `Statistical analysis of hypothetical sports scenario`,
      matchup_type: this.identifyMatchupType(parsedHypothetical),
      win_probability: matchupAnalysis.winProbability,
      key_numbers: {
        team_a_win_prob: matchupAnalysis.teamA.winProb,
        team_b_win_prob: matchupAnalysis.teamB.winProb,
        expected_score_diff: matchupAnalysis.expectedScoreDiff,
        confidence_interval: hasRealtimeData ? 0.78 : 0.68
      },
      factors: [
        "Historical performance metrics",
        "Head-to-head records",
        "Current form and momentum",
        "Injury reports and roster changes",
        "Home field advantage"
      ],
      sources: [
        { title: "Sports Statistics Database", url: "#", retrieved_at: TimeUtils.now() },
        { title: "Performance Analytics", url: "#", retrieved_at: TimeUtils.now() }
      ]
    };

    return {
      normalized: parsedHypothetical,
      assumptions: [
        "Teams perform at historical average levels",
        "No major injuries or roster changes",
        "Standard playing conditions and officiating"
      ],
      analyses: [analysis],
      uncertainties: [
        "Individual player performance variability",
        "Weather and playing conditions",
        "Psychological factors and momentum shifts",
        "Officiating decisions and rule interpretations"
      ],
      image_prompt: this.generateImagePrompt(parsedHypothetical, 'photo').prompt,
      citations: analysis.sources,
      disclaimer: "Sports predictions are inherently uncertain and for entertainment purposes only."
    };
  }

  identifyMatchupType(parsedHypothetical) {
    const text = parsedHypothetical.normalized.toLowerCase();
    
    if (text.includes('series')) return 'playoff_series';
    if (text.includes('championship') || text.includes('final')) return 'championship';
    if (text.includes('season')) return 'season_analysis';
    
    return 'single_game';
  }

  analyzeMatchup(parsedHypothetical, hasRealtimeData = false) {
    // Simulate statistical analysis with real-time data enhancement
    const baseStrength = 0.4 + Math.random() * 0.4; // 0.4 to 0.8
    const teamAStrength = hasRealtimeData ? Math.min(baseStrength * 1.1, 0.9) : baseStrength;
    const teamBStrength = 1 - teamAStrength;
    
    return {
      teamA: {
        winProb: teamAStrength,
        expectedScore: 100 + Math.random() * 20
      },
      teamB: {
        winProb: teamBStrength,
        expectedScore: 100 + Math.random() * 20
      },
      expectedScoreDiff: Math.abs(teamAStrength - teamBStrength) * 20,
      winProbability: Math.max(teamAStrength, teamBStrength)
    };
  }
}

// Finance Specialist
class FinanceSpecialist extends BaseSpecialist {
  constructor() {
    super('Finance Analyst', 'finance');
    this.financeKeywords = [
      'stock', 'market', 'price', 'revenue', 'profit', 'investment', 'valuation',
      'earnings', 'dividend', 'ipo', 'merger', 'acquisition', 'debt', 'equity'
    ];
  }

  extractKeywords(text) {
    const words = text.toLowerCase().split(/\W+/);
    return words.filter(word => 
      word.length > 3 && this.financeKeywords.includes(word)
    );
  }

  async analyze(parsedHypothetical, dataBundle = {}) {
    await DataUtils.simulateDelay(1800);

    // Use dataBundle for enhanced financial analysis if available
    const hasRealtimeData = Object.keys(dataBundle).length > 0;
    const marketImpact = this.calculateMarketImpact(parsedHypothetical, hasRealtimeData);
    
    const analysis = {
      name: "Financial Impact Analysis",
      summary: `Market impact assessment of hypothetical scenario`,
      impact_type: this.identifyImpactType(parsedHypothetical),
      market_reaction: marketImpact,
      key_numbers: {
        expected_price_change: marketImpact.priceChange,
        volatility_increase: marketImpact.volatility,
        market_cap_impact: marketImpact.marketCapImpact,
        confidence_level: hasRealtimeData ? 0.80 : 0.70
      },
      risk_factors: [
        "Market sentiment and investor psychology",
        "Regulatory response and policy changes",
        "Competitive landscape shifts",
        "Macroeconomic conditions"
      ],
      scenarios: this.generateScenarios(parsedHypothetical),
      sources: [
        { title: "Financial Markets Database", url: "#", retrieved_at: TimeUtils.now() },
        { title: "Economic Impact Models", url: "#", retrieved_at: TimeUtils.now() }
      ]
    };

    return {
      normalized: parsedHypothetical,
      assumptions: [
        "Markets operate efficiently with rational actors",
        "No major external economic shocks",
        "Regulatory environment remains stable"
      ],
      analyses: [analysis],
      uncertainties: [
        "Market timing and investor sentiment",
        "Regulatory and policy responses",
        "Competitive reactions and market dynamics",
        "Macroeconomic factors and global events"
      ],
      image_prompt: this.generateImagePrompt(parsedHypothetical, 'illustration').prompt,
      citations: analysis.sources,
      disclaimer: "Financial analysis is speculative and not investment advice."
    };
  }

  identifyImpactType(parsedHypothetical) {
    const text = parsedHypothetical.normalized.toLowerCase();
    
    if (text.includes('earnings') || text.includes('revenue')) return 'earnings_impact';
    if (text.includes('merger') || text.includes('acquisition')) return 'ma_activity';
    if (text.includes('product') || text.includes('launch')) return 'product_launch';
    
    return 'market_event';
  }

  calculateMarketImpact(parsedHypothetical, hasRealtimeData = false) {
    // Simulate financial modeling with real-time data enhancement
    const baseImpact = (Math.random() - 0.5) * 0.3; // -15% to +15%
    const adjustedImpact = hasRealtimeData ? baseImpact * 1.2 : baseImpact;
    const volatility = 0.1 + Math.random() * 0.2; // 10% to 30%
    
    return {
      priceChange: adjustedImpact,
      volatility: volatility,
      marketCapImpact: adjustedImpact * (1 + Math.random()) * 1000000000, // Billions
      timeframe: '1-3 months'
    };
  }

  generateScenarios(parsedHypothetical) {
    return [
      "Bull case: Positive market reception and strong execution",
      "Base case: Mixed market reaction with moderate impact",
      "Bear case: Negative sentiment and execution challenges"
    ];
  }
}

// Economics Specialist
class EconomicsSpecialist extends BaseSpecialist {
  constructor() {
    super('Economics Analyst', 'economics');
  }

  async analyze(parsedHypothetical, dataBundle = {}) {
    await DataUtils.simulateDelay(1600);

    // Use dataBundle for enhanced economic analysis if available
    const hasRealtimeData = Object.keys(dataBundle).length > 0;
    const economicImpact = this.assessEconomicImpact(parsedHypothetical, hasRealtimeData);
    
    const analysis = {
      name: "Economic Impact Assessment",
      summary: `Macroeconomic analysis of hypothetical policy or event`,
      impact_scope: this.determineScope(parsedHypothetical),
      economic_indicators: economicImpact.indicators,
      key_numbers: {
        gdp_impact: economicImpact.gdpImpact,
        employment_effect: economicImpact.employmentEffect,
        inflation_impact: economicImpact.inflationImpact,
        confidence_level: hasRealtimeData ? 0.75 : 0.65
      },
      transmission_mechanisms: [
        "Consumer spending and confidence",
        "Business investment and expansion",
        "Government fiscal policy response",
        "International trade and capital flows"
      ],
      sources: [
        { title: "Economic Research Database", url: "#", retrieved_at: TimeUtils.now() },
        { title: "Macroeconomic Models", url: "#", retrieved_at: TimeUtils.now() }
      ]
    };

    return {
      normalized: parsedHypothetical,
      assumptions: [
        "Ceteris paribus - other factors remain constant",
        "Standard economic relationships hold",
        "No major external shocks or policy changes"
      ],
      analyses: [analysis],
      uncertainties: [
        "Economic model limitations and assumptions",
        "Policy response and implementation effectiveness",
        "Global economic conditions and spillover effects",
        "Behavioral and psychological factors"
      ],
      image_prompt: this.generateImagePrompt(parsedHypothetical, 'isometric').prompt,
      citations: analysis.sources,
      disclaimer: "Economic projections are estimates based on historical patterns and models."
    };
  }

  determineScope(parsedHypothetical) {
    const text = parsedHypothetical.normalized.toLowerCase();
    
    if (text.includes('global') || text.includes('world')) return 'global';
    if (text.includes('national') || text.includes('country')) return 'national';
    if (text.includes('regional') || text.includes('state')) return 'regional';
    
    return 'sectoral';
  }

  assessEconomicImpact(parsedHypothetical, hasRealtimeData = false) {
    // Enhanced analysis with real-time data
    const multiplier = hasRealtimeData ? 1.15 : 1.0;
    
    return {
      gdpImpact: (Math.random() - 0.5) * 0.1 * multiplier, // -5% to +5%
      employmentEffect: (Math.random() - 0.5) * 0.08 * multiplier, // -4% to +4%
      inflationImpact: (Math.random() - 0.5) * 0.04 * multiplier, // -2% to +2%
      indicators: {
        consumer_confidence: Math.random() * 100,
        business_investment: (Math.random() - 0.5) * 0.15 * multiplier,
        trade_balance: (Math.random() - 0.5) * 50000000000 * multiplier
      }
    };
  }
}

// Weather Specialist
class WeatherSpecialist extends BaseSpecialist {
  constructor() {
    super('Weather Analyst', 'weather');
  }

  async analyze(parsedHypothetical, dataBundle = {}) {
    await DataUtils.simulateDelay(1000);

    // Use dataBundle for enhanced weather analysis if available
    const hasRealtimeData = Object.keys(dataBundle).length > 0;
    const weatherImpact = this.analyzeWeatherImpact(parsedHypothetical, hasRealtimeData);
    
    const analysis = {
      name: "Weather Impact Analysis",
      summary: `Meteorological analysis of hypothetical weather scenario`,
      weather_type: this.identifyWeatherType(parsedHypothetical),
      impact_assessment: weatherImpact,
      key_numbers: {
        probability: weatherImpact.probability,
        severity_index: weatherImpact.severity,
        affected_area: weatherImpact.affectedArea,
        duration_days: weatherImpact.duration
      },
      affected_sectors: [
        "Transportation and logistics",
        "Agriculture and food production",
        "Energy generation and distribution",
        "Tourism and outdoor activities"
      ],
      sources: [
        { title: "Meteorological Database", url: "#", retrieved_at: TimeUtils.now() },
        { title: "Climate Analysis Models", url: "#", retrieved_at: TimeUtils.now() }
      ]
    };

    return {
      normalized: parsedHypothetical,
      assumptions: [
        "Standard atmospheric conditions apply",
        "No major climate pattern disruptions",
        "Current forecasting accuracy levels"
      ],
      analyses: [analysis],
      uncertainties: [
        "Chaotic nature of weather systems",
        "Climate change effects on patterns",
        "Local geographical influences",
        "Forecasting model limitations"
      ],
      image_prompt: this.generateImagePrompt(parsedHypothetical, 'photo').prompt,
      citations: analysis.sources,
      disclaimer: "Weather predictions become less accurate over longer time periods."
    };
  }

  identifyWeatherType(parsedHypothetical) {
    const text = parsedHypothetical.normalized.toLowerCase();
    
    if (text.includes('hurricane') || text.includes('storm')) return 'severe_storm';
    if (text.includes('drought') || text.includes('dry')) return 'drought';
    if (text.includes('flood') || text.includes('rain')) return 'precipitation';
    if (text.includes('heat') || text.includes('temperature')) return 'temperature';
    
    return 'general_weather';
  }

  analyzeWeatherImpact(parsedHypothetical, hasRealtimeData = false) {
    // Enhanced analysis with real-time weather data
    const accuracyMultiplier = hasRealtimeData ? 1.2 : 1.0;
    
    return {
      probability: Math.min((0.3 + Math.random() * 0.5) * accuracyMultiplier, 0.95), // 30% to 80%
      severity: Math.random() * 10, // 0 to 10 scale
      affectedArea: Math.random() * 1000000, // Square kilometers
      duration: Math.floor(Math.random() * 14) + 1, // 1 to 14 days
      economicImpact: Math.random() * 10000000000 // Up to $10B
    };
  }
}

// Business Specialist
class BusinessSpecialist extends BaseSpecialist {
  constructor() {
    super('Business Analyst', 'business');
  }

  async analyze(parsedHypothetical, dataBundle = {}) {
    await DataUtils.simulateDelay(1400);

    // Use dataBundle for enhanced business analysis if available
    const hasRealtimeData = Object.keys(dataBundle).length > 0;
    const businessImpact = this.assessBusinessImpact(parsedHypothetical, hasRealtimeData);
    
    const analysis = {
      name: "Business Strategy Analysis",
      summary: `Strategic business analysis of hypothetical scenario`,
      analysis_framework: "Porter's Five Forces + SWOT Analysis",
      business_impact: businessImpact,
      key_numbers: {
        market_share_impact: businessImpact.marketShareChange,
        revenue_impact: businessImpact.revenueImpact,
        competitive_advantage: businessImpact.competitiveScore,
        implementation_cost: businessImpact.implementationCost
      },
      strategic_factors: [
        "Competitive positioning and differentiation",
        "Market size and growth potential",
        "Operational capabilities and resources",
        "Customer adoption and retention"
      ],
      sources: [
        { title: "Business Strategy Framework", url: "#", retrieved_at: TimeUtils.now() },
        { title: "Market Analysis Database", url: "#", retrieved_at: TimeUtils.now() }
      ]
    };

    return {
      normalized: parsedHypothetical,
      assumptions: [
        "Rational market behavior and competition",
        "Stable regulatory and economic environment",
        "Standard business execution capabilities"
      ],
      analyses: [analysis],
      uncertainties: [
        "Competitive response and market dynamics",
        "Customer adoption rates and preferences",
        "Execution risks and operational challenges",
        "Regulatory and policy changes"
      ],
      image_prompt: this.generateImagePrompt(parsedHypothetical, 'illustration').prompt,
      citations: analysis.sources,
      disclaimer: "Business analysis is based on current market conditions and strategic frameworks."
    };
  }

  assessBusinessImpact(parsedHypothetical, hasRealtimeData = false) {
    // Enhanced analysis with real-time market data
    const multiplier = hasRealtimeData ? 1.1 : 1.0;
    
    return {
      marketShareChange: (Math.random() - 0.5) * 0.2 * multiplier, // -10% to +10%
      revenueImpact: (Math.random() - 0.5) * 2000000000 * multiplier, // -$1B to +$1B
      competitiveScore: Math.random() * 10, // 0 to 10 scale
      implementationCost: Math.random() * 500000000, // Up to $500M
      timeToMarket: Math.floor(Math.random() * 24) + 1 // 1 to 24 months
    };
  }
}

// Specialist Registry
class SpecialistRegistry {
  constructor() {
    this.specialists = {
      history: new HistorySpecialist(),
      sports: new SportsSpecialist(),
      finance: new FinanceSpecialist(),
      economics: new EconomicsSpecialist(),
      weather: new WeatherSpecialist(),
      business: new BusinessSpecialist()
    };
  }

  getSpecialist(lens) {
    return this.specialists[lens] || null;
  }

  getAllSpecialists() {
    return Object.keys(this.specialists);
  }

  /**
   * Auto-select specialist based on hypothetical content
   */
  autoSelectSpecialist(hypothetical) {
    const text = hypothetical.toLowerCase();
    const scores = {};

    // Score each specialist based on keyword matches
    for (const [lens, specialist] of Object.entries(this.specialists)) {
      const keywords = specialist.extractKeywords(text);
      scores[lens] = keywords.length;
    }

    // Return specialist with highest score, or history as default
    const bestMatch = Object.entries(scores).reduce((a, b) => 
      scores[a[0]] > scores[b[0]] ? a : b
    );

    return bestMatch[1] > 0 ? bestMatch[0] : 'history';
  }
}

// Export for use in other modules
window.SpecialistRegistry = SpecialistRegistry;
window.BaseSpecialist = BaseSpecialist;